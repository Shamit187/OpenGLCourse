g++ clock.cpp -o clock -lglut -lGLU -lGL
./clock
g++ magic_cube.cpp -o magic_cube -lglut -lGLU -lGL
./magic_cube